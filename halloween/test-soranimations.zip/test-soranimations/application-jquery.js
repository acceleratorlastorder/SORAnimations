/*
function makeNewPosition(){

    // Get viewport dimensions (remove the dimension of the div)
    var h = $(window).height() - 50;
    var w = $(window).width() - 50;

    var nh = Math.floor(Math.random() * h);
    var nw = Math.floor(Math.random() * w);

    return [nh,nw];

}

function animateDiv(){
    var newq = makeNewPosition();
    $('.blue-circle').animate({ top: newq[0], left: newq[1] }, function(){
      animateDiv();
    });

};
*/



$(document).ready(function() {


  $('#startButton').click(function() {
    for (var i = 1; i <= 50; i++) {
    $('.red-circle').animate({
            left: "400"
        }, "slow")
        .animate({
            top: "-160",
            height: "200",
            width: "200"
        }, "slow")
        .animate({
            left: "0",
            height: "100",
            width: "100"
        }, "slow")
        .animate({
            top: "0"
        }, "slow")
        .slideUp()
        .slideDown("slow")
    };

    for (var i = 1; i <= 50; i++) {
    $('.blue-circle').animate({
            left: "400"
        }, "slow")
        .animate({
            top: "-160",
            height: "200",
            width: "200"
        }, "slow")
        .animate({
            left: "0",
            height: "100",
            width: "100"
        }, "slow")
        .animate({
            top: "0"
        }, "slow")
        .slideUp()
        .slideDown("slow");

    };


    $('.blue-circle').click(function() {
        $('.blue-circle').hide();
        $('.blue-circle').clone();
    });

    $('.red-circle').click(function() {
        $('.red-circle').hide();
    });

  });
    /*
for (var i = 1; i <= 10; i++) {
};
                 var copie = $('.blue-circle').clone();
                  copie.find('.marque').html('peugeot');
                  copie.find('.couleur').html('rouge').css('color', 'red');
                  copie.appendTo('body');

                    $('.blue-circle').clone().html($('.blue-circle').html());


    */

});
